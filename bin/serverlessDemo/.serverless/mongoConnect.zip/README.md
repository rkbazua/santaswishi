# santaswishi

Solo es una demo. Borrar después.

Instrucciones:

1.- Descargar aws cli, node y serverless (sls) en windows. Asegurarse que ambos ejecutables estén en el path
2.- Configurar aws cli con el comando: aws configure. Utiliza las claves programáticas que puedes ver en evernote (por ahora), apunta la región a us-west1 (N California)
3.- Corre npm install para descargar todas las dependencias
4.- Corre sls deploy para hacer deploy en dev (default) y us-east1 (default). Utiliza flags para cambiar la región y el stage.
5.- El deploy debe realizarse sin problema